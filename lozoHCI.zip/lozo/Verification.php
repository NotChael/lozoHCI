<html>
    <head>
        <title>verification.php</title>
        <?php include ('./conn/conn.php');session_start();
        if (isset($_SESSION['user_verification_id'])) {
            $userVerificationID = $_SESSION['user_verification_id'];
        }
        ?>

        <style>
            * {
                margin: 0;
                padding: 0;
                font-family: 'Poppins', sans-serif;
            }
            
            body {
                display: flex;
                justify-content: center;
                align-items: center;
                background-image: url("");
                background-size: cover;
                background-repeat: no-repeat;
                background-attachment: fixed;
                height: 100vh;
            }
            .verification-container, .verification-form {
                backdrop-filter: blur(100px);
                color: rgb(250, 255, 255);
                padding: 40px;
                width: 500px;
                border: 2px solid;
                border-radius: 10px;
            }
        </style>
            
    </head>
    <body>
        <div class="main">
            <div class="verification-container">
                <div class="verification-form" id="loginForm">
                    <h2 class="text-center">Email Verification</h2>
                    <p class="text-center">Please check your email for verification code.</p>
                    <form action="Verification.php" method="POST">
        <input type="text" name="user_verification_id" value="<?= $userVerificationID ?>" hidden>
        <input type="number" class="form-control text-center" id="verificationCode" 
        name="verification_code">
        <button type="submit" class="btn btn-secondary login-btn form-control mt-4" 
        name="verify">Verify</button>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>